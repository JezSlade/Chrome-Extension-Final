// ui/utils.js
// Minimal reactive store, DOM helpers, modal, theme, sync utilities, and shared UI bits.

export const appEl = () => document.getElementById('app');

export function el(tag, attrs = {}, ...children){
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})){
    if (k === 'class') e.className = v;
    else if (k === 'html') e.innerHTML = v;
    else if (k.startsWith('on') && typeof v === 'function') e.addEventListener(k.slice(2).toLowerCase(), v);
    else e.setAttribute(k, v);
  }
  for (const c of children){
    if (c == null) continue;
    if (c instanceof Node) { e.appendChild(c); continue; }
    if (Array.isArray(c)) { c.forEach(x => x && e.appendChild(x instanceof Node ? x : document.createTextNode(String(x)))); continue; }
    e.appendChild(document.createTextNode(String(c)));
  }
  return e;
}

export function cls(elm, classes){
  if (!elm) return;
  Object.entries(classes || {}).forEach(([k,v]) => elm.classList.toggle(k, !!v));
}

export function $(sel, root=document){ return root.querySelector(sel); }
export function $all(sel, root=document){ return Array.from(root.querySelectorAll(sel)); }

/* ---------- Toasts ---------- */
let toastSeq = 0;
export function showToast(msg, opts={}){
  const id = `tf-toast-${++toastSeq}`;
  const box = el('div', { id, class:'toast glass' }, msg);
  document.body.appendChild(box);
  setTimeout(()=> box.classList.add('show'), 0);
  const t = opts.duration || 2400;
  setTimeout(()=>{ box.classList.remove('show'); setTimeout(()=> box.remove(), 300); }, t);
}

/* ---------- Simple state store ---------- */
let __state = { filter:'', sync:{ phase:'idle', last:null }, tab:'expansions', data:{} };
let __subs = [];
export function getState(){ return __state; }
export function setState(patch){
  __state = Object.assign({}, __state, patch||{});
  __subs.forEach(fn => { try{ fn(__state); } catch(_){} });
}
export function subscribe(fn){ __subs.push(fn); return ()=> __subs = __subs.filter(x => x!==fn); }

/* ---------- Modal ---------- */
let modalSeq = 0;
const modalStack = [];
export function openModal(opts){
  const { title, body, actions } = opts || {};
  const id = `tf-modal-${++modalSeq}`;

  const backdrop = el('div', { class: 'modal-backdrop', id });
  const modal = el('div', { class: 'modal glass', role: 'dialog', 'aria-modal': 'true' });

  modal.addEventListener('click', (e)=> e.stopPropagation());

  const onBackdropClick = (e) => {
    if (e.target === backdrop && modalStack.length && modalStack[modalStack.length - 1] === backdrop){
      closeModal(backdrop);
    }
  };
  backdrop.addEventListener('click', onBackdropClick);

  const onKey = (e) => {
    if (e.key === 'Escape' && modalStack length && modalStack[modalStack.length - 1] === backdrop){
      closeModal(backdrop);
    }
  };
  document.addEventListener('keydown', onKey);

  const header = el('div', { class: 'modal-header' },
    el('h3', {}, title || 'Edit'),
    el('button', { class:'btn secondary', onclick: ()=> closeModal(backdrop) }, 'Close')
  );
  const content = el('div', { class: 'modal-body' });
  if (body) content.appendChild(body);
  const footer = el('div', { class: 'modal-footer' });
  (actions||[]).forEach(a => footer.appendChild(a));

  modal.appendChild(header);
  modal.appendChild(content);
  modal.appendChild(footer);
  backdrop.appendChild(modal);
  document.body.appendChild(backdrop);
  setTimeout(()=> backdrop.classList.add('show'), 0);
  modalStack.push(backdrop);
  return { close: ()=> closeModal(backdrop), content };
}
export function closeModal(backdrop){
  if (!backdrop) return;
  const idx = modalStack.lastIndexOf(backdrop);
  if (idx !== -1) modalStack.splice(idx,1);
  backdrop.classList.remove('show');
  setTimeout(()=> backdrop.remove(), 150);
}

/* ---------- Toolbar ---------- */
export function Toolbar({ title, buttons }={}){
  const left = el('div', { class:'row' }, title ? el('strong', {}, title) : null);
  const right = el('div', { class:'row' }, ...(buttons||[]));
  return el('div', { class:'toolbar' }, left, right);
}

/* ---------- Filter & Sync Status ---------- */
export function FilterAndSync(){
  const s = getState();
  const right = el('div', { class:'row middle' },
    el('button', { class:'btn secondary', onclick: ()=> doPull() }, 'Pull'),
    el('button', { class:'btn secondary', onclick: ()=> doPush() }, 'Push')
  );
  const sync = s.sync || {};
  const label = sync.phase === 'pushing'
    ? 'Sync: pushing...'
    : sync.phase === 'pulling'
      ? 'Sync: pulling...'
      : (sync.last ? `Last sync: ${new Date(sync.last.at).toLocaleString()} ${sync.last.ok ? '✓' : '✕'}` : 'No sync yet.');
  right.appendChild(el('div', { class:'small', style:'margin-left:8px' }, label));

  return el('div', { class:'row between' },
    el('input', {
      class:'input',
      placeholder:'Filter...',
      value: s.filter,
      'data-focus-key':'tf-filter',
      oninput:(e)=>{ setState({ filter: e.target.value }); }
    }),
    right
  );
}
export function applyFilter(list){
  const q = (getState().filter || '').trim().toLowerCase();
  if (!q) return list;
  return list.filter(x => JSON.stringify(x).toLowerCase().includes(q));
}
export const uid = () => Math.floor(Math.random()*1e9);

/* ---------- Markdown editor (Quick Formatting) ---------- */
function wrapSelection(t, before, after=''){
  const s = t.selectionStart || 0, e = t.selectionEnd || 0;
  const val = t.value;
  const pre = val.slice(0, s);
  const mid = val.slice(s, e);
  const post = val.slice(e);
  t.value = pre + before + mid + after + post;
  const pos = (pre + before + mid + after).length;
  t.focus();
  t.setSelectionRange(pos, pos);
}
export function MarkdownEditor({ value='', oninput }){
  const ta = el('textarea', { class:'input code', oninput:(e)=> oninput && oninput(e.target.value) }, value);
  const bar = el('div', { class:'row wrap gap' },
    el('button', { class:'btn secondary', onclick: ()=> wrapSelection(ta, '**','**') }, 'Bold'),
    el('button', { class:'btn secondary', onclick: ()=> wrapSelection(ta, '*','*') }, 'Italic'),
    el('button', { class:'btn secondary', onclick: ()=> wrapSelection(ta, '`','`') }, 'Code'),
    el('button', { class:'btn secondary', onclick: ()=> wrapSelection(ta, '```\\n','\\n```') }, 'Code Block'),
    el('button', { class:'btn secondary', onclick: ()=> wrapSelection(ta, '- ','') }, 'Bullet'),
    el('button', { class:'btn secondary', onclick: ()=> wrapSelection(ta, '1. ','') }, 'Numbered'),
    el('button', { class:'btn secondary', onclick: ()=> wrapSelection(ta, '> ','') }, 'Quote')
  );
  return el('div', {}, bar, ta);
}

/* ---------- Wizard Stepper ---------- */
export function WizardStepper({ steps=[], current=1 }){
  const row = el('div', { class:'row wrap gap' });
  steps.forEach((s, i) => {
    const idx = i + 1;
    const it = el('div', { class:'step' },
      el('div', { class:'step-num' }, String(idx)),
      el('div', { class:'step-label' }, s)
    );
    if (idx === current) it.classList.add('active');
    row.appendChild(it);
  });
  return row;
}

/* ---------- Focus helper ---------- */
export function focusByKey(key){
  const elx = document.querySelector(`[data-focus-key=\"${CSS.escape(key)}\"]`);
  if (elx) elx.focus();
}

/* ---------- RPC ---------- */
export async function rpc(type, payload){
  // Send both 'action' and 'type' for compatibility with different backgrounds
  const res = await chrome.runtime.sendMessage({ action: type, type, ...(payload||{}) });
  if (res && res.error) throw new Error(res.error);
  return res || {};
}

/* ---------- Sync helpers ---------- */
async function persistLastSync(last){
  const cur = getState().sync || {};
  const s = { sync: Object.assign({}, cur, { last }) };
  setState(s);
}
export async function doPush(){
  const cur = getState().sync || {};
  setState({ sync: Object.assign({}, cur, { phase: 'pushing' }) });
  let ok = false, details = '';
  try {
    const res = await chrome.runtime.sendMessage({ action: 'SYNC_PUSH' });
    ok = !!(res && res.ok);
    details = (res && (res.details || res.message)) || '';
  } catch (e){
    details = e && e.message || 'push error';
  }
  const last = { action:'push', ok, at: Date.now(), details };
  await persistLastSync(last);
  setState({ sync: { phase: 'idle', last } });
}
export async function doPull(){
  const cur = getState().sync || {};
  setState({ sync: Object.assign({}, cur, { phase: 'pulling' }) });
  let ok = false, details = '';
  try {
    const res = await chrome.runtime.sendMessage({ action: 'SYNC_PULL' });
    ok = !!(res && res.ok);
    details = (res && (res.details || res.message)) || '';
  } catch (e){
    details = e && e.message || 'pull error';
  }
  const last = { action:'pull', ok, at: Date.now(), details };
  await persistLastSync(last);
  setState({ sync: { phase: 'idle', last } });
}
export const triggerAutoSyncPush = debounce(doPush, 700);

/* ---------- Debounce ---------- */
export function debounce(fn, wait=300){
  let t; return (...args)=>{ clearTimeout(t); t = setTimeout(()=> fn(...args), wait); };
}

// ---------------------------------------------
// DRY Helpers for Element Labels & Generic CRUD
// ---------------------------------------------

// Human-readable labels for form element types (internal keys kept intact)
export const FORM_TYPE_LABELS = Object.freeze({
  text: 'Single-line Text',
  textarea: 'Multi-line Text',
  number: 'Number',
  date: 'Date',
  select: 'Dropdown',
  file: 'File Upload',
  boolean: 'Yes/No Toggle',
  json: 'JSON Data (Advanced)'
});

export function formTypeLabel(type){
  return FORM_TYPE_LABELS[type] || String(type || '').trim() || 'Unknown';
}

export function formTypeOptions(current){
  // Returns <option> nodes with friendly labels while preserving values
  const keys = Object.keys(FORM_TYPE_LABELS);
  return keys.map(k => el('option', { value:k, selected: current === k }, FORM_TYPE_LABELS[k]));
}

// Name validation and normalization for Variables / Form Elements / AI Elements
export function normalizeName(name){
  const n = (name || '').trim();
  return n.replace(/[\\s\\u00A0]+/g, ' ').slice(0, 128);
}
export function isValidName(name){
  const n = normalizeName(name);
  return n.length >= 1 && n.replace(/\\s+/g,'').length >= 1;
}
export function ensureUniqueName(baseName, existingNames){
  const set = new Set((existingNames || []).map(x => (x||'').toLowerCase()));
  let candidate = normalizeName(baseName);
  if (!set.has(candidate.toLowerCase())) return candidate;
  let i = 2;
  while (set.has((candidate + ' ' + i).toLowerCase())) i++;
  return candidate + ' ' + i;
}

// Generic CRUD store adapter to keep modules thin and consistent
// Expects RPC functions already implemented in background.js
export function createCrudAdapter({ stateKey, listRpc, addRpc, updateRpc, deleteRpc }){
  if (!stateKey || !listRpc || !addRpc || !updateRpc || !deleteRpc){
    throw new Error('createCrudAdapter: missing required keys');
  }
  async function list(){
    const res = await rpc(listRpc);
    const items = (res && (res.items || res[stateKey] || [])) || [];
    const s = {}; s[stateKey] = items; setState(s);
    return items;
  }
  async function add(item){
    const res = await rpc(addRpc, { item });
    await list();
    triggerAutoSyncPush();
    return res && (res.id || res.ok);
  }
  async function update(id, patch){
    await rpc(updateRpc, { id, patch });
    await list();
    triggerAutoSyncPush();
  }
  async function remove(id){
    await rpc(deleteRpc, { id });
    await list();
    triggerAutoSyncPush();
  }
  return { list, add, update, remove };
}

// AI Prompt Element library helpers
// Group prompts by AI provider/model so the UI can render per-AI libraries with CRUD.
export function groupBy(items, key){
  const out = {};
  (items || []).forEach(it => {
    const k = (it && it[key]) || 'default';
    if (!out[k]) out[k] = [];
    out[k].push(it);
  });
  return out;
}

export function groupPromptsByAI(items){
  // Uses 'provider' || 'model' || 'engine' fields commonly found in prompt items
  const byProvider = groupBy(items, 'provider');
  // Within each provider, group by model if present
  const out = {};
  Object.keys(byProvider).forEach(p => {
    const models = groupBy(byProvider[p], 'model');
    out[p] = models;
  });
  return out;
}

// ---------------------------------------------
// Layout & Render helpers expected by app.js
// ---------------------------------------------
export function withSidebar(side, main){
  const wrap = el('div', { class:'layout' },
    el('aside', { class:'sidebar-wrap' }, side),
    el('section', { class:'main-wrap' }, main)
  );
  return wrap;
}

export function renderWithFocus(fn){
  // Preserve focused control via data-focus-key during re-render
  const active = document.activeElement;
  const key = active && active.getAttribute && active.getAttribute('data-focus-key');
  fn();
  if (key) {
    try { focusByKey(key); } catch(_){}
  }
}

export function injectTheme(){
  // No-op placeholder; can be extended to toggle theme variables.
  // Kept to satisfy existing calls without changing behavior.
}

export function closeContextMenu(){
  const menu = document.getElementById('contextMenu');
  if (!menu) return;
  menu.classList.add('hidden');
  const list = document.getElementById('contextMenuItems');
  if (list) list.innerHTML = '';
}
