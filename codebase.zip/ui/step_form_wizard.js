class StepFormWizardModal {
  constructor(options = {}) {
    // Default configuration
    this.config = {
      containerId: options.containerId || 'wizardModal',
      steps: options.steps || [],
      showProgressBar: options.showProgressBar !== false,
      showStepNumbers: options.showStepNumbers !== false,
      allowStepSkipping: options.allowStepSkipping || false,
      validateOnNext: options.validateOnNext !== false,
      closeOnBackdrop: options.closeOnBackdrop !== false,
      closeOnEscape: options.closeOnEscape !== false,
      animation: options.animation !== false,
      theme: options.theme || 'default',
      ...options
    };

    // State management
    this.state = {
      currentStep: 0,
      isOpen: false,
      formData: {},
      stepValidation: {},
      completedSteps: new Set()
    };

    // Event callbacks
    this.callbacks = {
      onStepChange: options.onStepChange || (() => {}),
      onComplete: options.onComplete || (() => {}),
      onCancel: options.onCancel || (() => {}),
      onValidate: options.onValidate || (() => true),
      onBeforeStepChange: options.onBeforeStepChange || (() => true)
    };

    this.container = null;
    this.modal = null;
    
    this.init();
  }

  init() {
    this.createModal();
    this.bindEvents();
    this.applyTheme();
  }

  createModal() {
    // Create modal container
    this.container = document.getElementById(this.config.containerId);
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.id = this.config.containerId;
      document.body.appendChild(this.container);
    }

    // Build modal HTML
    this.container.innerHTML = this.getModalHTML();
    this.modal = this.container.querySelector('.wizard-modal');
    
    // Hide initially
    this.container.style.display = 'none';
  }

  getModalHTML() {
    return `
      <div class="wizard-backdrop">
        <div class="wizard-modal">
          <div class="wizard-header">
            <h3 class="wizard-title">${this.config.title || 'Step Wizard'}</h3>
            <button class="wizard-close" type="button">&times;</button>
          </div>
          
          ${this.config.showProgressBar ? this.getProgressBarHTML() : ''}
          
          <div class="wizard-body">
            <div class="wizard-steps-container">
              ${this.getStepsHTML()}
            </div>
          </div>
          
          <div class="wizard-footer">
            <div class="wizard-navigation">
              <button class="wizard-btn wizard-btn-secondary wizard-prev" type="button" disabled>
                Previous
              </button>
              <button class="wizard-btn wizard-btn-primary wizard-next" type="button">
                Next
              </button>
              <button class="wizard-btn wizard-btn-success wizard-complete" type="button" style="display: none;">
                Complete
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  getProgressBarHTML() {
    const steps = this.config.steps;
    let progressHTML = '<div class="wizard-progress">';
    
    if (this.config.showStepNumbers) {
      progressHTML += '<div class="wizard-step-indicators">';
      steps.forEach((step, index) => {
        progressHTML += `
          <div class="wizard-step-indicator ${index === 0 ? 'active' : ''}" data-step="${index}">
            <div class="step-number">${index + 1}</div>
            <div class="step-title">${step.title}</div>
          </div>
        `;
      });
      progressHTML += '</div>';
    }
    
    progressHTML += `
      <div class="wizard-progress-bar">
        <div class="wizard-progress-fill" style="width: ${100 / steps.length}%"></div>
      </div>
    </div>`;
    
    return progressHTML;
  }

  getStepsHTML() {
    return this.config.steps.map((step, index) => `
      <div class="wizard-step ${index === 0 ? 'active' : ''}" data-step="${index}">
        <div class="step-content">
          ${step.content || ''}
        </div>
      </div>
    `).join('');
  }

  bindEvents() {
    const backdrop = this.container.querySelector('.wizard-backdrop');
    const closeBtn = this.container.querySelector('.wizard-close');
    const prevBtn = this.container.querySelector('.wizard-prev');
    const nextBtn = this.container.querySelector('.wizard-next');
    const completeBtn = this.container.querySelector('.wizard-complete');

    // Close events
    if (this.config.closeOnBackdrop) {
      backdrop.addEventListener('click', (e) => {
        if (e.target === backdrop) this.close();
      });
    }

    closeBtn.addEventListener('click', () => this.close());

    // Navigation events
    prevBtn.addEventListener('click', () => this.previousStep());
    nextBtn.addEventListener('click', () => this.nextStep());
    completeBtn.addEventListener('click', () => this.complete());

    // Step indicator clicks (if step skipping allowed)
    if (this.config.allowStepSkipping) {
      const indicators = this.container.querySelectorAll('.wizard-step-indicator');
      indicators.forEach((indicator, index) => {
        indicator.addEventListener('click', () => this.goToStep(index));
      });
    }

    // Keyboard events
    if (this.config.closeOnEscape) {
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && this.state.isOpen) {
          this.close();
        }
      });
    }

    // Form input events for data collection
    this.container.addEventListener('input', (e) => {
      this.collectFormData();
    });
  }

  open(initialData = {}) {
    this.state.isOpen = true;
    this.state.formData = { ...initialData };
    this.container.style.display = 'block';
    
    if (this.config.animation) {
      this.container.classList.add('wizard-fade-in');
    }
    
    this.updateStepDisplay();
    return this;
  }

  close() {
    this.state.isOpen = false;
    
    if (this.config.animation) {
      this.container.classList.add('wizard-fade-out');
      setTimeout(() => {
        this.container.style.display = 'none';
        this.container.classList.remove('wizard-fade-out');
      }, 300);
    } else {
      this.container.style.display = 'none';
    }
    
    this.callbacks.onCancel(this.state.formData);
    return this;
  }

  nextStep() {
    if (!this.canProceedToNext()) return false;

    if (this.state.currentStep < this.config.steps.length - 1) {
      this.goToStep(this.state.currentStep + 1);
    }
    return true;
  }

  previousStep() {
    if (this.state.currentStep > 0) {
      this.goToStep(this.state.currentStep - 1);
    }
    return true;
  }

  goToStep(stepIndex) {
    if (stepIndex < 0 || stepIndex >= this.config.steps.length) return false;

    // Check if step change is allowed
    if (!this.callbacks.onBeforeStepChange(this.state.currentStep, stepIndex, this.state.formData)) {
      return false;
    }

    const previousStep = this.state.currentStep;
    this.state.currentStep = stepIndex;
    this.state.completedSteps.add(previousStep);

    this.updateStepDisplay();
    this.callbacks.onStepChange(stepIndex, previousStep, this.state.formData);
    
    return true;
  }

  canProceedToNext() {
    if (!this.config.validateOnNext) return true;

    const currentStepData = this.getCurrentStepData();
    const isValid = this.callbacks.onValidate(this.state.currentStep, currentStepData, this.state.formData);
    
    this.state.stepValidation[this.state.currentStep] = isValid;
    
    if (!isValid) {
      this.showValidationError();
    }
    
    return isValid;
  }

  updateStepDisplay() {
    const steps = this.container.querySelectorAll('.wizard-step');
    const indicators = this.container.querySelectorAll('.wizard-step-indicator');
    const prevBtn = this.container.querySelector('.wizard-prev');
    const nextBtn = this.container.querySelector('.wizard-next');
    const completeBtn = this.container.querySelector('.wizard-complete');

    // Update step visibility
    steps.forEach((step, index) => {
      step.classList.toggle('active', index === this.state.currentStep);
    });

    // Update step indicators
    indicators.forEach((indicator, index) => {
      indicator.classList.toggle('active', index === this.state.currentStep);
      indicator.classList.toggle('completed', this.state.completedSteps.has(index));
    });

    // Update progress bar
    if (this.config.showProgressBar) {
      const progressFill = this.container.querySelector('.wizard-progress-fill');
      const progressPercent = ((this.state.currentStep + 1) / this.config.steps.length) * 100;
      progressFill.style.width = `${progressPercent}%`;
    }

    // Update navigation buttons
    prevBtn.disabled = this.state.currentStep === 0;
    
    const isLastStep = this.state.currentStep === this.config.steps.length - 1;
    nextBtn.style.display = isLastStep ? 'none' : 'inline-block';
    completeBtn.style.display = isLastStep ? 'inline-block' : 'none';
  }

  collectFormData() {
    const currentStep = this.container.querySelector('.wizard-step.active');
    const formElements = currentStep.querySelectorAll('input, select, textarea');
    
    formElements.forEach(element => {
      const name = element.name || element.id;
      if (name) {
        if (element.type === 'checkbox') {
          this.state.formData[name] = element.checked;
        } else if (element.type === 'radio') {
          if (element.checked) {
            this.state.formData[name] = element.value;
          }
        } else {
          this.state.formData[name] = element.value;
        }
      }
    });
  }

  getCurrentStepData() {
    this.collectFormData();
    return this.state.formData;
  }

  showValidationError() {
    const currentStep = this.container.querySelector('.wizard-step.active');
    currentStep.classList.add('validation-error');
    
    setTimeout(() => {
      currentStep.classList.remove('validation-error');
    }, 3000);
  }

  complete() {
    if (!this.canProceedToNext()) return false;

    this.collectFormData();
    this.callbacks.onComplete(this.state.formData);
    this.close();
    return true;
  }

  // Public API methods
  setStepContent(stepIndex, content) {
    if (stepIndex >= 0 && stepIndex < this.config.steps.length) {
      this.config.steps[stepIndex].content = content;
      const stepElement = this.container.querySelector(`[data-step="${stepIndex}"] .step-content`);
      if (stepElement) {
        stepElement.innerHTML = content;
      }
    }
    return this;
  }

  getFormData() {
    this.collectFormData();
    return { ...this.state.formData };
  }

  setFormData(data) {
    this.state.formData = { ...this.state.formData, ...data };
    this.populateFormFields();
    return this;
  }

  populateFormFields() {
    Object.keys(this.state.formData).forEach(name => {
      const element = this.container.querySelector(`[name="${name}"], #${name}`);
      if (element) {
        if (element.type === 'checkbox') {
          element.checked = !!this.state.formData[name];
        } else if (element.type === 'radio') {
          if (element.value === this.state.formData[name]) {
            element.checked = true;
          }
        } else {
          element.value = this.state.formData[name];
        }
      }
    });
  }

  reset() {
    this.state.currentStep = 0;
    this.state.formData = {};
    this.state.stepValidation = {};
    this.state.completedSteps.clear();
    this.updateStepDisplay();
    return this;
  }

  applyTheme() {
    // Inject CSS styles
    if (!document.getElementById('wizard-modal-styles')) {
      const style = document.createElement('style');
      style.id = 'wizard-modal-styles';
      style.textContent = this.getCSS();
      document.head.appendChild(style);
    }
  }

  getCSS() {
    return `
      .wizard-backdrop {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
      }

      .wizard-modal {
        background: white;
        border-radius: 8px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        max-width: 600px;
        width: 90%;
        max-height: 90vh;
        overflow: hidden;
        display: flex;
        flex-direction: column;
      }

      .wizard-header {
        padding: 20px;
        border-bottom: 1px solid #e9ecef;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }

      .wizard-title {
        margin: 0;
        color: #333;
        font-size: 1.25rem;
      }

      .wizard-close {
        background: none;
        border: none;
        font-size: 1.5rem;
        cursor: pointer;
        color: #999;
        padding: 0;
        width: 30px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .wizard-close:hover {
        color: #333;
      }

      .wizard-progress {
        padding: 20px;
        background: #f8f9fa;
        border-bottom: 1px solid #e9ecef;
      }

      .wizard-step-indicators {
        display: flex;
        justify-content: space-between;
        margin-bottom: 15px;
      }

      .wizard-step-indicator {
        text-align: center;
        flex: 1;
        cursor: pointer;
        transition: all 0.3s ease;
      }

      .wizard-step-indicator .step-number {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        background: #e9ecef;
        color: #999;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 5px;
        font-weight: bold;
        transition: all 0.3s ease;
      }

      .wizard-step-indicator.active .step-number {
        background: #007bff;
        color: white;
      }

      .wizard-step-indicator.completed .step-number {
        background: #28a745;
        color: white;
      }

      .wizard-step-indicator .step-title {
        font-size: 0.85rem;
        color: #666;
      }

      .wizard-step-indicator.active .step-title {
        color: #007bff;
        font-weight: bold;
      }

      .wizard-progress-bar {
        background: #e9ecef;
        height: 4px;
        border-radius: 2px;
        overflow: hidden;
      }

      .wizard-progress-fill {
        background: linear-gradient(90deg, #007bff, #0056b3);
        height: 100%;
        transition: width 0.3s ease;
      }

      .wizard-body {
        flex: 1;
        overflow-y: auto;
        padding: 20px;
      }

      .wizard-step {
        display: none;
      }

      .wizard-step.active {
        display: block;
        animation: fadeIn 0.3s ease;
      }

      .wizard-step.validation-error {
        animation: shake 0.5s ease;
      }

      .wizard-footer {
        padding: 20px;
        border-top: 1px solid #e9ecef;
        background: #f8f9fa;
      }

      .wizard-navigation {
        display: flex;
        justify-content: space-between;
        gap: 10px;
      }

      .wizard-btn {
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-weight: bold;
        transition: all 0.3s ease;
      }

      .wizard-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }

      .wizard-btn-primary {
        background: #007bff;
        color: white;
      }

      .wizard-btn-primary:hover:not(:disabled) {
        background: #0056b3;
      }

      .wizard-btn-secondary {
        background: #6c757d;
        color: white;
      }

      .wizard-btn-secondary:hover:not(:disabled) {
        background: #545b62;
      }

      .wizard-btn-success {
        background: #28a745;
        color: white;
      }

      .wizard-btn-success:hover {
        background: #1e7e34;
      }

      .wizard-fade-in {
        animation: fadeIn 0.3s ease;
      }

      .wizard-fade-out {
        animation: fadeOut 0.3s ease;
      }

      @keyframes fadeIn {
        from { opacity: 0; transform: scale(0.95); }
        to { opacity: 1; transform: scale(1); }
      }

      @keyframes fadeOut {
        from { opacity: 1; transform: scale(1); }
        to { opacity: 0; transform: scale(0.95); }
      }

      @keyframes shake {
        0%, 100% { transform: translateX(0); }
        25% { transform: translateX(-5px); }
        75% { transform: translateX(5px); }
      }

      /* Responsive */
      @media (max-width: 768px) {
        .wizard-modal {
          width: 95%;
          max-height: 95vh;
        }
        
        .wizard-step-indicators {
          flex-direction: column;
          gap: 10px;
        }
        
        .wizard-step-indicator {
          display: flex;
          align-items: center;
          text-align: left;
        }
        
        .wizard-step-indicator .step-number {
          margin-right: 10px;
          margin-bottom: 0;
        }
      }
    `;
  }
}

// Export for use
if (typeof module !== 'undefined' && module.exports) {
  module.exports = StepFormWizardModal;
} else if (typeof window !== 'undefined') {
  window.StepFormWizardModal = StepFormWizardModal;
}