// ui/modules/forms.js
// Refocused as Element Configuration for form-related templates.
// Keeps id and RPCs intact, but presents CRUD for reusable form elements via Variables.
import { el, rpc, getState, setState, Toolbar, applyFilter, showToast, withSidebar, openModal, closeModal, MarkdownEditor, triggerAutoSyncPush } from '../utils.js';

export const id = 'forms';
export const label = 'Element Configuration (Forms)';

function toolbar(){
  return Toolbar({
    buttons: [
      el('button', { class:'btn', onclick: ()=> openNewFormElementWizard() }, 'New Form Element')
    ]
  });
}

async function reload(){ const st = await rpc('GET_STATE'); setState({ data: st.data }); }

/* ----- Wizard to create/edit a reusable form element (stored as a Variable) ----- */
function openNewFormElementWizard(prefill){
  const draft = Object.assign({ name:'', type:'text', default:'', options:[] }, prefill||{});
  let step = 1;

  const stepper = ()=> el('div', { class:'stepper' },
    el('div', { class:'step'+(step===1?' active':'') }, '1. Name'),
    el('div', { class:'step'+(step===2?' active':'') }, '2. Type'),
    el('div', { class:'step'+(step===3?' active':'') }, '3. Content')
  );

  const s1 = el('div', {},
    el('label', {}, 'Element name'),
    el('input', { class:'input', value:draft.name, oninput:(e)=> draft.name = e.target.value }),
    el('div', { class:'row' }, el('button', { class:'btn', onclick: ()=>{ if (!draft.name.trim()) return; step=2; renderBody(); } }, 'Next'))
  );

  const s2 = el('div', {},
    el('label', {}, 'Type'),
    el('select', { class:'input', onchange:(e)=> draft.type = e.target.value },
      ...['text','textarea','number','date','select','file','boolean','json'].map(t => el('option', { value:t, selected:draft.type===t }, t))
    ),
    el('div', { class:'row' }, el('button', { class:'btn', onclick: ()=>{ step=3; renderBody(); } }, 'Next'))
  );

  const s3 = el('div', {},
    el('label', {}, 'Default / Format'),
    MarkdownEditor({ value:draft.default||'', oninput:(v)=> draft.default = v }),
    draft.type==='select'
      ? el('div', {}, el('div', { class:'small' }, 'Options (comma separated)'), el('input', { class:'input', value:(draft.options||[]).join(', '), oninput:(e)=>{ draft.options = e.target.value.split(',').map(s=>s.trim()).filter(Boolean); } }))
      : (draft.type==='date'
          ? el('div', { class:'small' }, 'Date format like %Y-%m-%d.')
          : el('div', { class:'small' }, ''))
  );

  const wrap = el('div', {});
  function renderBody(){
    wrap.innerHTML = '';
    wrap.appendChild(stepper());
    wrap.appendChild(step===1?s1:step===2?s2:s3);
  }
  renderBody();

  openModal({
    title: prefill ? 'Edit Form Element' : 'New Form Element',
    body: wrap,
    actions: [
      el('button', { class:'btn secondary', onclick: closeModal }, 'Cancel'),
      el('button', { class:'btn', onclick: async ()=>{
        if (!draft.name.trim()) return;
        if (prefill && prefill.id){
          await rpc('UPDATE_VARIABLE', { id: prefill.id, patch: draft });
        } else {
          await rpc('ADD_VARIABLE', { item: draft });
        }
        await reload();
        triggerAutoSyncPush();
        closeModal();
        showToast('Saved');
      } }, 'Save')
    ]
  });
}

function list(){
  // Filter variables that are typical form elements
  const vars = (getState().data.variables || []).filter(v => ['text','textarea','number','date','select','file','boolean','json'].includes(v.type));
  const items = applyFilter(vars);
  const grid = el('div', { class:'grid cols-2 list' },
    ...items.map(v => el('div', { class:'card' },
      el('div', { class:'row between' },
        el('strong', {}, `${v.name} (${v.type})`),
        el('div', {},
          el('button', { class:'btn secondary', onclick: ()=> openNewFormElementWizard(v) }, 'Edit'),
          el('button', { class:'btn secondary', onclick: async ()=>{ await rpc('DELETE_VARIABLE', { id:v.id }); await reload(); triggerAutoSyncPush(); showToast('Deleted'); } }, 'Delete')
        )
      ),
      el('textarea', {}, v.default || '')
    ))
  );
  return grid;
}

function librarySidebar(){
  const vars = (getState().data.variables || []).filter(v => ['text','textarea','number','date','select','file','boolean','json'].includes(v.type));
  const wrap = el('div', { class:'card' }, el('h3', {}, 'Library'));
  if (!vars.length){ wrap.appendChild(el('div', { class:'small' }, 'No form elements yet.')); return wrap; }
  vars.forEach(v => {
    wrap.appendChild(el('div', { class:'row' }, el('button', { class:'btn secondary', onclick: ()=> openNewFormElementWizard(v) }, `${v.name}  #${v.id}`)));
  });
  return wrap;
}

export function render(){
  const main = el('div', {});
  main.appendChild(el('div', { class:'card' }, el('h3', {}, 'Element Configuration — Forms')));
  main.appendChild(el('div', { class:'small' }, 'Manage reusable form element templates. Insert them from the Cue editor.'));
  main.appendChild(toolbar());
  main.appendChild(list());
  return withSidebar(librarySidebar(), main);
}
